/*    ==Par�metros de Script==

    Vers�o do Servidor de Origem : SQL Server 2008 R2 (10.50.6000)
    Edi��o do Mecanismo de Banco de Dados de Origem : Microsoft SQL Server Standard Edition
    Tipo do Mecanismo de Banco de Dados de Origem : SQL Server Aut�nomo

    Vers�o do Servidor de Destino : SQL Server 2008 R2
    Edi��o de Mecanismo de Banco de Dados de Destino : Microsoft SQL Server Standard Edition
    Tipo de Mecanismo de Banco de Dados de Destino : SQL Server Aut�nomo
*/

USE [Controle]
GO

/****** Object:  View [SWISSPORT].[EMPLOYEE_BASE_DATA]    Script Date: 20/09/2017 11:03:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER VIEW [SWISSPORT].[EMPLOYEE_BASE_DATA] 
--[PPSPIMP1].[FPW_Swissport].
AS

select distinct
	FUN.FUMATFUNC "EmployeeNo", 

	REVERSE(SUBSTRING(REVERSE(FUN.FUNOMFUNC), 0, CHARINDEX(' ', REVERSE(FUN.FUNOMFUNC)))) "LastName" ,
	SUBSTRING(FUN.FUNOMFUNC, 1, CHARINDEX(' ',FUN.FUNOMFUNC ) -1) "FirstName",
	FUN.FUDTADMIS "EntryDate",
	''"ExitDate",
	--CONVERT(CHAR,OCO.OFDTINIOCO +1,103  )"ExitDate",
	FUN.FUDTNASC "BirthDate",
	FUN.FUENDERECO "Street",
	FUN.FUNUMERO "StreetNo",
	MUM.MUDESMUNIC "City",
	FUN.FUCEP "ZIPCode",
	FUN.FUEMAIL "Email",
	CONVERT(VARCHAR(    30  ),FUN.FUDDD) + CONVERT(VARCHAR(    30  ),FUN.FUTELEFONE) "Phone1",
	CONVERT(VARCHAR(    30  ),FUN.FUDDD) + CONVERT(VARCHAR(    30  ),FUN.FUCELULAR) "Phone2",
	'' "Phone3",
	FUN.FUHORMENS "ContractName",
	OCO.OFDtIniOco "BeginDateContract"

	
	from [PPSPIMP1].[FPw_Swissport].DBO.FUNCIONA as fUN
	
	LEFT JOIN [PPSPIMP1].[FPw_Swissport].DBO.MUNICIP as MUM
		on FUN.FUCODMUNIC = MUM.MUCODMUNIC 

	LEFT JOIN [PPSPIMP1].[FPw_Swissport].DBO.SITUACAO as SAT
		on  SAT.STTipoSitu in ('N','F','A')
	
	LEFT JOIN [PPSPIMP1].[FPw_Swissport].DBO.OCORFUNC as OCO
		on OCO.OFMATFUNC = FUN.FUMATFUNC 
		And FUN.FUMATFUNC = OCO.OFMATFUNC

	
		
						
		WHERE 
			fUN.FUCODEMP = OCO.OFCODEMP
			  AND OCO.OFCODOCORR = 1006
				
					AND OCO.OFDtIniOco  = 
					(SELECT 
						CASE
							WHEN MAX(OCO.OFDtIniOco) is null THEN FUN.FUDTADMIS
							ELSE MAX(OCO.OFDtIniOco)
						END
					FROM [PPSPIMP1].[FPw_Swissport].DBO.OCORFUNC as OCO
					WHERE FUN.FUMATFUNC = OCO.OFMATFUNC)

									   
GO


