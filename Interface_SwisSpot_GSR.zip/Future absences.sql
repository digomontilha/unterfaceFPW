/*    ==Par�metros de Script==

    Vers�o do Servidor de Origem : SQL Server 2008 R2 (10.50.6000)
    Edi��o do Mecanismo de Banco de Dados de Origem : Microsoft SQL Server Standard Edition
    Tipo do Mecanismo de Banco de Dados de Origem : SQL Server Aut�nomo

    Vers�o do Servidor de Destino : SQL Server 2008 R2
    Edi��o de Mecanismo de Banco de Dados de Destino : Microsoft SQL Server Standard Edition
    Tipo de Mecanismo de Banco de Dados de Destino : SQL Server Aut�nomo
*/

USE [Controle]
GO

/****** Object:  View [SWISSPORT].[FUTURE_ABSENCES ]    Script Date: 20/09/2017 11:03:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER VIEW [SWISSPORT].[FUTURE_ABSENCES ]
as
SELECT 
	OCO.OFMATFUNC "EmployeeNo", 
	SIT.STDESCSITU "AbsenceCode",
	OCO.OFDTINIOCO "StartDate",
	OCO.OFDTFINOCO "EndDate"
	
	
		FROM [PPSPIMP1].[FPW_Swissport].DBO.OCORFUNC as OCO
		
		LEFT JOIN [PPSPIMP1].[FPW_Swissport].DBO.SITUACAO as SIT
			on SIT.STCODSITU = OCO.OFCODPROXS
		
		where  OFCodOcorr = 1001 
		AND CONVERT(char(10),OCO.OFDTINIOCO,112) >= getdate() +1
		AND CONVERT(char(10),OCO.OFDTINIOCO,112) <= getdate() +364

GO


