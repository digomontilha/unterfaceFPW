/*    ==Par�metros de Script==

    Vers�o do Servidor de Origem : SQL Server 2008 R2 (10.50.6000)
    Edi��o do Mecanismo de Banco de Dados de Origem : Microsoft SQL Server Standard Edition
    Tipo do Mecanismo de Banco de Dados de Origem : SQL Server Aut�nomo

    Vers�o do Servidor de Destino : SQL Server 2008 R2
    Edi��o de Mecanismo de Banco de Dados de Destino : Microsoft SQL Server Standard Edition
    Tipo de Mecanismo de Banco de Dados de Destino : SQL Server Aut�nomo
*/

USE [Controle]
GO

/****** Object:  View [SWISSPORT].[PAST_ABSENCES]    Script Date: 20/09/2017 11:03:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





ALTER VIEW [SWISSPORT].[PAST_ABSENCES] 
as

Select 
	ENT.EPMATRICULA "EmployeeNo",
	REPLACE(CONVERT( CHAR(20),REPLACE(ENT.EPHRENT, ':', '')+'-'+ 
	REPLACE(ENT.EPHRSAI, ':', ''), 120),' ','')	"ShiftCode",
	
	
	REPLACE(CONVERT( CHAR(10), ENT.EPDATA, 112 ),' ','') "StartDate",
	REPLACE(CONVERT( CHAR(10), ENT.EPDATA, 112 ),' ','') "EndDate",
	REPLACE(ENT.EPHRENT, ':', '') "IntervalStart",
	REPLACE(ENT.EPHRSAI, ':', '') "IntervalEnd",
	JUS.JUDESCR  "Timetype"
	
	
	From
		[PPSPIMP1].[FPw_Swissport].DBO.JUSTIFIC as JUS
	
	

	LEFT JOIN [PPSPIMP1].[FPw_Swissport].DBO.ENTRPONT as ENT
		ON JUS.JUCODIGO = ENT.EPJUSTENT 
	
	LEFT JOIN [PPSPIMP1].[FPw_Swissport].DBO.HORARIO as HOR
		ON HOR.HOCODIGO = ENT.EPESCALA AND  ENT.EPEMPSIS = HOR.HOEMPSIS


		WHERE  ENT.EPDATA between getdate()-11 
			and DATEADD(DAY, -3 , GETDATE()) 
			
			

			
GO


